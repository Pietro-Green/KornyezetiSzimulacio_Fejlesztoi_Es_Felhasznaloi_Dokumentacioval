﻿using System;
using System.IO;

namespace OOP_ASS_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Adatok allapot = Adatok.beOlvas();  //Singleton tervezesi minta (csak egyetlen objektumot peldanyositunk a bemenet alapjan, es a kesobbiekben is azt manipulaljuk, nem hozunk ujakat letre!)
            allapot.kiIrat();

            //allapot.korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat().korSzim().kiIrat();
            //Fluent interface tervezesi minta (lehetové teszi muveletek lancolasat egy objektumon (itt pl return this segitsegevel))
            
            for (int i = 0; i <= 9; i++)
            {
                allapot.korSzim();
                Console.WriteLine("A szimulacio {0}. kore utan az idojaras {1}, valamint", i+1, allapot.idojarasKiszamitas());
                allapot.kiIrat();
            }

            allapot.legVizesebbTulajaKiIrasa();

            Console.Write("\n\tA kilepeshez nyomja meg barmely gombot");
            Console.ReadKey();
            Console.Write("\n\n\t\t NEE NE AZT A GOMBOT AAA\n");
        }
    }
}