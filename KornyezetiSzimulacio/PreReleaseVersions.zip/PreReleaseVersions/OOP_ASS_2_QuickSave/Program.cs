﻿using System;
using System.IO;

namespace OOP_ASS_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Adatok allapot = Adatok.beOlvas();
            allapot.kiIrat();
            
            for (int i = 0; i <= 9; i++)
            {
                Adatok.korSzim(allapot);
                Console.WriteLine("A szimulacio {0}. kore utan:", i+1);
                allapot.kiIrat();
            }

            Console.Write("\n\tA kilepeshez nyomjon meg barmilyen gombot");
            Console.ReadKey();
            Console.Write("\n");
        }
    }
}