﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_ASS_2
{

    internal class FoldTerulet
    {
        public string   tulaj;
        public char     fajta;
        public int      viz;

        public FoldTerulet(string egyTulaj, char egyFajta, int egyViz)
        {
            tulaj   = egyTulaj;
            fajta   = egyFajta;
            viz     = egyViz;
        }

    }

}